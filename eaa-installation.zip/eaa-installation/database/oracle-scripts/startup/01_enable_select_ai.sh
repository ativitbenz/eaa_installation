#!/bin/bash
# Enable Oracle Select AI (DBMS_CLOUD_AI) for the application user created by
# 00_create_user.sh. The Free image does not ship DBMS_CLOUD, so this installs
# it, gives the database a wallet of trusted root CAs for HTTPS calls to LLM
# providers, and grants the network and wallet access both the package owner
# (C##CLOUD$SERVICE, checked in CDB$ROOT) and the application user (checked in
# FREEPDB1) need. See docs/database/oracle/select-ai-setup.md.
#
# The image sources this file as SYSDBA on every start, so each step checks
# before it acts and nothing here may call exit. The first start installs the
# package, which takes several minutes; later starts only re-apply grants.
# The wallet lives in the oradata volume so it survives a recreated container.

enable_select_ai() {
  local user="${ORACLE_USER:-chatbot}"
  local admin="$ORACLE_HOME/rdbms/admin"
  local wallet="/opt/oracle/oradata/dbms_cloud_wallet"
  local sqlplus="$ORACLE_HOME/bin/sqlplus"
  local orapki="$ORACLE_HOME/bin/orapki"

  if [[ ! "$user" =~ ^[A-Za-z][A-Za-z0-9_]{0,127}$ ]]; then
    echo "Select AI: ORACLE_USER must be a plain Oracle identifier: $user" >&2
    return 1
  fi

  pdb_value() {
    "$sqlplus" -s "/ as sysdba" <<SQL | tr -d '[:space:]'
SET HEADING OFF FEEDBACK OFF PAGESIZE 0
ALTER SESSION SET CONTAINER = FREEPDB1;
$1
EXIT;
SQL
  }

  run_catcon() {
    local name="$1" script="$2"
    echo "Select AI: running $script"
    (cd "$admin" && "$ORACLE_HOME/perl/bin/perl" catcon.pl \
      --force_pdb_mode 'READ WRITE' \
      -b "$name" -d "$admin" -l /tmp "$script") || return 1
  }

  # 1. DBMS_CLOUD: the owner user first, or the package lands half-installed in SYS.
  local packages
  packages=$(pdb_value "SELECT COUNT(*) FROM dba_objects WHERE owner = 'C##CLOUD\$SERVICE' AND object_name IN ('DBMS_CLOUD', 'DBMS_CLOUD_AI') AND object_type = 'PACKAGE' AND status = 'VALID';")
  if [ "$packages" != "2" ]; then
    echo "Select AI: installing DBMS_CLOUD, this takes several minutes"
    run_catcon cloud_user catclouduser.sql || { echo "Select AI: catclouduser.sql failed, see /tmp/cloud_user*.log" >&2; return 1; }
    run_catcon dbms_cloud_install dbms_cloud_install.sql || { echo "Select AI: dbms_cloud_install.sql failed, see /tmp/dbms_cloud_install*.log" >&2; return 1; }
  fi

  # 2. A wallet of the system's root CAs. orapki takes one certificate at a
  # time; a few fail as duplicates, which is expected.
  if [ ! -f "$wallet/cwallet.sso" ]; then
    echo "Select AI: creating the root CA wallet"
    mkdir -p "$wallet"
    "$orapki" wallet create -wallet "$wallet" -auto_login_only >/dev/null
    local certs
    certs=$(mktemp -d)
    awk -v dir="$certs" '/BEGIN CERT/{n++} n{print > (dir "/cert" n ".pem")}' /etc/pki/tls/certs/ca-bundle.crt
    for cert in "$certs"/cert*.pem; do
      "$orapki" wallet add -wallet "$wallet" -trusted_cert -cert "$cert" -auto_login_only >/dev/null 2>&1
    done
    rm -rf "$certs"
  fi

  # 3-5. SSL_WALLET is set in CDB$ROOT only (a PDB raises ORA-65040 and
  # inherits it). DBMS_CLOUD checks its owner's network access in CDB$ROOT
  # (ORA-20401 without it) and the calling user's in FREEPDB1.
  "$sqlplus" -s "/ as sysdba" <<SQL
SET FEEDBACK OFF
WHENEVER SQLERROR CONTINUE

DECLARE
  current_wallet VARCHAR2(4000);
BEGIN
  SELECT MAX(property_value) INTO current_wallet
    FROM database_properties WHERE property_name = 'SSL_WALLET';
  IF current_wallet IS NULL OR current_wallet <> '${wallet}' THEN
    EXECUTE IMMEDIATE 'ALTER DATABASE PROPERTY SET ssl_wallet = ''${wallet}''';
  END IF;
END;
/

BEGIN
  DBMS_NETWORK_ACL_ADMIN.APPEND_HOST_ACE(
    host => '*',
    ace  => xs\$ace_type(
      privilege_list => xs\$name_list('http', 'connect', 'resolve'),
      principal_name => 'C##CLOUD\$SERVICE',
      principal_type => xs_acl.ptype_db
    )
  );
END;
/

ALTER SESSION SET CONTAINER = FREEPDB1;

GRANT EXECUTE ON C##CLOUD\$SERVICE.DBMS_CLOUD TO ${user};
GRANT EXECUTE ON C##CLOUD\$SERVICE.DBMS_CLOUD_AI TO ${user};

BEGIN
  FOR principal IN (SELECT UPPER('${user}') AS name FROM dual
                    UNION ALL SELECT 'C##CLOUD\$SERVICE' FROM dual) LOOP
    DBMS_NETWORK_ACL_ADMIN.APPEND_WALLET_ACE(
      wallet_path => 'file:${wallet}',
      ace => xs\$ace_type(
        privilege_list => xs\$name_list('use_client_certificates', 'use_passwords'),
        principal_name => principal.name,
        principal_type => xs_acl.ptype_db
      )
    );
  END LOOP;
END;
/

EXIT;
SQL
  echo "Select AI: enabled for ${user}"
}

enable_select_ai
unset -f enable_select_ai pdb_value run_catcon
