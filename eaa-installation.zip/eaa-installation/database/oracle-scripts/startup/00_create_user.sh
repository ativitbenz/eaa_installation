#!/bin/bash
# Create the application user and grant what it needs. The Oracle Free image
# ships a prebuilt database, so it never runs scripts/setup; it sources the
# files in scripts/startup as SYSDBA on every start, which is why everything
# here must be safe to repeat. The user name and password come from the
# container environment (ORACLE_USER and ORACLE_PASSWORD in docker-compose.yml);
# compose files that do not pass them keep the previous development user and
# password. An existing user keeps its password.

ORACLE_USER="${ORACLE_USER:-chatbot}"
if [[ ! "$ORACLE_USER" =~ ^[A-Za-z][A-Za-z0-9_]{0,127}$ ]]; then
  echo "ORACLE_USER must be a plain Oracle identifier: $ORACLE_USER" >&2
  exit 1
fi

"$ORACLE_HOME"/bin/sqlplus -s "/ as sysdba" <<SQL
ALTER SESSION SET CONTAINER = FREEPDB1;

DECLARE
  existing NUMBER;
BEGIN
  SELECT COUNT(*) INTO existing FROM dba_users WHERE username = UPPER('${ORACLE_USER}');
  IF existing = 0 THEN
    EXECUTE IMMEDIATE 'CREATE USER ${ORACLE_USER} IDENTIFIED BY "${ORACLE_PASSWORD:-chatbot_pass_123}"'
      || ' DEFAULT TABLESPACE USERS TEMPORARY TABLESPACE TEMP QUOTA UNLIMITED ON USERS';
    DBMS_OUTPUT.PUT_LINE('User ${ORACLE_USER} created');
  END IF;
END;
/

GRANT CREATE SESSION TO ${ORACLE_USER};
GRANT CREATE TABLE TO ${ORACLE_USER};
GRANT CREATE VIEW TO ${ORACLE_USER};
GRANT CREATE SEQUENCE TO ${ORACLE_USER};
GRANT CREATE PROCEDURE TO ${ORACLE_USER};
GRANT CREATE TRIGGER TO ${ORACLE_USER};
GRANT UNLIMITED TABLESPACE TO ${ORACLE_USER};
GRANT CREATE ANY INDEX TO ${ORACLE_USER};
GRANT CREATE CREDENTIAL TO ${ORACLE_USER};
GRANT CREATE MINING MODEL TO ${ORACLE_USER};

-- Oracle AI Vector Search
GRANT EXECUTE ON DBMS_VECTOR TO ${ORACLE_USER};
GRANT EXECUTE ON DBMS_VECTOR_CHAIN TO ${ORACLE_USER};

-- Outbound calls to embedding and LLM providers.
BEGIN
  DBMS_NETWORK_ACL_ADMIN.APPEND_HOST_ACE(
    host => '*',
    ace  => xs\$ace_type(
      privilege_list => xs\$name_list('http', 'connect', 'resolve'),
      principal_name => UPPER('${ORACLE_USER}'),
      principal_type => xs_acl.ptype_db
    )
  );
END;
/

EXIT;
SQL
